#ifndef ACTUATORCONFIG_H
#define ACTUATORCONFIG_H

/*
 * TMC6460 actuator configuration - velocity mode only.
 *
 * This build intentionally removes auto-calibration and position-command logic.
 * POSITION_ACTUAL is still read only as feedback for hard-end/stall detection.
 */

#define TMC6460_ENABLE_TORQUE_MODE                         0
#define TMC6460_ENABLE_POSITION_MODE                       0

/* Single torque/flux limit macro used by GUI defaults and safe holding. */
#define DEFAULT_VELOCITY_TORQUE_LIMIT_RAW                  3000
#define MIN_VELOCITY_TORQUE_LIMIT_RAW                      300
#define MAX_VELOCITY_TORQUE_LIMIT_RAW                      3000

/* Velocity-only end/stall monitor. */
#define TMC6460_ENABLE_ACTUATOR_STOP_DETECTION             1
#define TMC6460_CALIBRATION_LOG_EVERY_SAMPLE               1

/*
 * End/stall detection tuning.
 * The motor is allowed to run until it is really blocked at the end stop:
 *   position almost stopped + velocity low + torque/current loaded.
 *
 * If the motor is drawing too much current at the end with no load, lower
 * TMC6460_END_DETECT_CURRENT_MA_THRESHOLD or TMC6460_END_DETECT_TORQUE_RAW_THRESHOLD.
 */
#define TMC6460_END_DETECT_STARTUP_IGNORE_MS               1200
#define TMC6460_END_DETECT_MIN_TRAVEL_COUNTS               50000LL
#define TMC6460_END_DETECT_NO_PROGRESS_COUNTS              300LL
#define TMC6460_END_DETECT_LOW_VELOCITY_RAW                70000
#define TMC6460_END_DETECT_LOW_VELOCITY_RATIO_PERCENT      8
#define TMC6460_END_DETECT_TORQUE_RAW_THRESHOLD            80
#define TMC6460_END_DETECT_CURRENT_MA_THRESHOLD            60
#define TMC6460_END_DETECT_BLOCKED_SAMPLES                 2
#define TMC6460_END_DETECT_SAFETY_TIMEOUT_MS               30000

/*
 * Hold tuning after hard end / stall / E-stop / velocity=0.
 * 0 = use dedicated hold limit below.
 * 1 = use currently selected GUI Velocity Torque/Flux Limit.
 *
 * For no-load end testing, a lower hold limit reduces unnecessary current after stop.
 * For 10 kg load, increase TMC6460_END_HOLD_TORQUE_FLUX_LIMIT_RAW if it back-drives.
 */
#define TMC6460_HOLD_USES_RUNNING_TORQUE_LIMIT             0
#define TMC6460_END_HOLD_TORQUE_FLUX_LIMIT_RAW             300
#define TMC6460_SAFE_ESTOP_HOLD_TORQUE_FLUX_LIMIT_RAW      300

#endif // ACTUATORCONFIG_H
