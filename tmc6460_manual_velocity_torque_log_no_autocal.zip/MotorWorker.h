#ifndef MOTORWORKER_H
#define MOTORWORKER_H

#include "ActuatorConfig.h"
#include "Tmc6460QtInterface.h"

#include <QObject>
#include <QString>
#include <QTimer>
#include <QElapsedTimer>

#ifndef TMC6460_ENABLE_VELOCITY_RAMP
#define TMC6460_ENABLE_VELOCITY_RAMP 0
#endif

class MotorWorker : public QObject
{
    Q_OBJECT

public:
    explicit MotorWorker(QObject *parent = nullptr);
    ~MotorWorker() override;

public slots:
    void connectAndInitialize(const QString &portName, int baudRate);
    void readStatus();
    void applyTorque(int value);
    void applyVelocityTorqueLimitRaw(int torqueLimitRaw);
    void applyVelocityLimitRaw(qint32 limitRaw);
    void applyVelocityRaw(qint32 rawVelocity);
    void readRunStatusSnapshot(const QString &tag);
    void emergencyStop();
    void shutdown();

signals:
    void connected(bool ok, quint32 chipId, const QString &message);
    void statusReady(const Tmc6460QtInterface::RunStatus &status);
    void commandDone(const QString &action, bool ok);
    void stallStateChanged(bool stalled, const QString &message);
    void logMessage(const QString &message);
    void errorChanged(const QString &message);

private slots:
    void processVelocityRamp();

private:
    Tmc6460QtInterface *tmc = nullptr;
    QTimer *velocityRampTimer = nullptr;

    qint32 currentCommandedVelocityRaw = 0;
    qint32 targetVelocityRaw = 0;

    static constexpr int VELOCITY_RAMP_TIMER_MS = 50;
    static constexpr qint32 VELOCITY_RAMP_STEP_RAW = 100000;
    static constexpr qint32 MAX_ALLOWED_VELOCITY_RAW = 10000000;
    static constexpr qint32 MAX_ALLOWED_TORQUE_RAW = MAX_VELOCITY_TORQUE_LIMIT_RAW;
    static constexpr qint32 CAL_MIN_TARGET_RAW = 100000;
    static constexpr int CAL_STATUS_SAMPLE_MS = 250;

    bool runMonitorActive = false;
    bool stopLatched = false;
    bool startPositionValid = false;
    bool directionLearned = false;
    qint32 targetVelocityForMonitorRaw = 0;
    int commandDirection = 0;
    int positionDirection = 0;
    quint32 startPositionRaw = 0;
    quint32 previousPositionRaw = 0;
    qint64 progressCounts = 0;
    int blockedSamples = 0;
    QElapsedTimer runTimer;

    bool holdingAtEnd = false;
    int holdingDirection = 0;

    qint32 activeVelocityTorqueFluxLimitRaw = DEFAULT_VELOCITY_TORQUE_LIMIT_RAW;

    qint16 runMinTorqueRaw = 0;
    qint16 runMaxTorqueRaw = 0;
    qint16 runMaxAbsTorqueRaw = 0;
    int runMaxCurrentMilliAmp = 0;
    int runSampleCount = 0;

    void ensureInterface();
    bool writeVelocityRaw(qint32 rawVelocity);
    void resetVelocityRampState();
    void startRunEndMonitor(qint32 rawVelocity);
    void stopRunEndMonitor(bool clearGuiStatus);
    void checkRunEndStop(const Tmc6460QtInterface::RunStatus &status);
    void handleRunEndStop(const QString &reason,
                          const Tmc6460QtInterface::RunStatus &status,
                          qint64 travelCounts);
    qint32 selectedHoldTorqueFluxLimitRaw() const;
    qint32 clampVelocityTorqueFluxLimit(qint32 raw) const;
    void resetTorqueLogStats();
    void updateTorqueLogStats(const Tmc6460QtInterface::RunStatus &status);
    void logTorqueSummary(const QString &tag,
                          const Tmc6460QtInterface::RunStatus &status,
                          qint64 travelCounts) const;
    static qint64 signedPositionDelta32(quint32 current, quint32 start);
    static QString hex32(quint32 value);
};

#endif
