#include "MotorWorker.h"

#include <QtGlobal>
#include <QDateTime>

MotorWorker::MotorWorker(QObject *parent)
    : QObject(parent)
{
    velocityRampTimer = new QTimer(this);
    velocityRampTimer->setInterval(VELOCITY_RAMP_TIMER_MS);
    velocityRampTimer->setSingleShot(false);

    connect(velocityRampTimer,
            &QTimer::timeout,
            this,
            &MotorWorker::processVelocityRamp);
}

MotorWorker::~MotorWorker()
{
    if (velocityRampTimer != nullptr)
    {
        velocityRampTimer->stop();
    }

    if (tmc != nullptr)
    {
        if (tmc->isOpen())
        {
            tmc->shutdownMotorSafe();
        }
        tmc->closePort();
    }
}

void MotorWorker::ensureInterface()
{
    if (tmc != nullptr)
        return;

    tmc = new Tmc6460QtInterface(this);
    connect(tmc, &Tmc6460QtInterface::logMessage, this, &MotorWorker::logMessage);
    connect(tmc, &Tmc6460QtInterface::errorChanged, this, &MotorWorker::errorChanged);
}

void MotorWorker::connectAndInitialize(const QString &portName, int baudRate)
{
    ensureInterface();

    resetVelocityRampState();
    stopRunEndMonitor(true);

    if (!tmc->openPort(portName.trimmed(), baudRate))
    {
        emit connected(false, 0, tmc->lastError());
        return;
    }

    if (!tmc->initializeMotor())
    {
        emit connected(false, 0, tmc->lastError());
        return;
    }

    quint32 chipId = 0;
    if (!tmc->readChipId(&chipId))
    {
        emit connected(false, 0, tmc->lastError());
        return;
    }

    activeVelocityTorqueFluxLimitRaw = DEFAULT_VELOCITY_TORQUE_LIMIT_RAW;
    tmc->setVelocityTorqueFluxLimit(activeVelocityTorqueFluxLimitRaw);

    emit connected(true, chipId, QStringLiteral("Connected and initialized. Use CW/CCW manually. Motor runs to hard end/stall and then applies limited safe hold. Auto calibration/auto reverse removed."));
}

void MotorWorker::readStatus()
{
    ensureInterface();

    if (!tmc->isOpen() || tmc->isBusy())
        return;

    Tmc6460QtInterface::RunStatus status;
    if (tmc->readRunStatus(&status))
    {
        emit errorChanged(QString());
        emit statusReady(status);

#if TMC6460_ENABLE_ACTUATOR_STOP_DETECTION
        checkRunEndStop(status);
#endif
    }
    else
    {
        emit errorChanged(tmc->lastError());
    }
}

void MotorWorker::applyTorque(int value)
{
    Q_UNUSED(value)

#if !TMC6460_ENABLE_TORQUE_MODE
    emit logMessage(QStringLiteral("TORQUE_MODE_DISABLED: torque commands are disabled. This build uses velocity mode only."));
    emit commandDone(QStringLiteral("Torque mode disabled"), false);
    return;
#else
    ensureInterface();

    resetVelocityRampState();
    stopRunEndMonitor(true);

    const int limitedTorque = qBound<int>(-MAX_ALLOWED_TORQUE_RAW, value, MAX_ALLOWED_TORQUE_RAW);
    const bool ok = tmc->isOpen() && tmc->setTorqueTarget(limitedTorque);
    emit commandDone(QStringLiteral("Torque target %1").arg(limitedTorque), ok);
#endif
}

qint32 MotorWorker::clampVelocityTorqueFluxLimit(qint32 raw) const
{
    return qBound<qint32>(MIN_VELOCITY_TORQUE_LIMIT_RAW,
                          qAbs(raw),
                          MAX_VELOCITY_TORQUE_LIMIT_RAW);
}

qint32 MotorWorker::selectedHoldTorqueFluxLimitRaw() const
{
#if TMC6460_HOLD_USES_RUNNING_TORQUE_LIMIT
    return clampVelocityTorqueFluxLimit(activeVelocityTorqueFluxLimitRaw);
#else
    return clampVelocityTorqueFluxLimit(TMC6460_END_HOLD_TORQUE_FLUX_LIMIT_RAW);
#endif
}

qint32 MotorWorker::selectedRunTorqueFluxLimitRawForDirection(qint32 rawVelocity) const
{
#if TMC6460_USE_DIRECTION_RUN_TORQUE_LIMITS
    if (rawVelocity < 0)
        return clampVelocityTorqueFluxLimit(TMC6460_CCW_LIFT_RUN_TORQUE_FLUX_LIMIT_RAW);
    return clampVelocityTorqueFluxLimit(TMC6460_CW_RELEASE_RUN_TORQUE_FLUX_LIMIT_RAW);
#else
    Q_UNUSED(rawVelocity)
    return clampVelocityTorqueFluxLimit(activeVelocityTorqueFluxLimitRaw);
#endif
}

void MotorWorker::applyVelocityLimitRaw(qint32 limitRaw)
{
    ensureInterface();

    const qint32 absLimit = qAbs(limitRaw);
    const qint32 limitedVelocityLimit = qBound<qint32>(1, absLimit, MAX_ALLOWED_VELOCITY_RAW);

    if (limitedVelocityLimit != absLimit)
    {
        emit logMessage(QStringLiteral("SAFETY: Velocity limit %1 clipped to %2")
                        .arg(absLimit)
                        .arg(limitedVelocityLimit));
    }

    if (!tmc->isOpen())
    {
        emit commandDone(QStringLiteral("Velocity limit raw=%1").arg(limitedVelocityLimit), false);
        emit errorChanged(QStringLiteral("Cannot apply velocity limit: serial port is not open"));
        return;
    }

    const bool ok = tmc->setVelocityLimitRaw(limitedVelocityLimit);
    emit commandDone(QStringLiteral("Velocity limit raw=%1").arg(limitedVelocityLimit), ok);

    if (!ok)
        emit errorChanged(QStringLiteral("Velocity limit write failed"));
}

void MotorWorker::applyVelocityTorqueLimitRaw(int torqueLimitRaw)
{
    ensureInterface();

    const int limitedTorqueLimit = clampVelocityTorqueFluxLimit(torqueLimitRaw);

    if (limitedTorqueLimit != qAbs(torqueLimitRaw))
    {
        emit logMessage(QStringLiteral("SAFETY: Velocity torque/flux limit %1 clipped to %2")
                        .arg(torqueLimitRaw)
                        .arg(limitedTorqueLimit));
    }

    activeVelocityTorqueFluxLimitRaw = limitedTorqueLimit;

    if (!tmc->isOpen())
    {
        emit commandDone(QStringLiteral("Velocity torque/flux limit %1").arg(limitedTorqueLimit), false);
        emit errorChanged(QStringLiteral("Cannot apply velocity torque/flux limit: serial port is not open"));
        return;
    }

    const bool ok = tmc->setVelocityTorqueFluxLimit(limitedTorqueLimit);
    emit commandDone(QStringLiteral("Velocity torque/flux limit %1").arg(limitedTorqueLimit), ok);

    if (!ok)
        emit errorChanged(QStringLiteral("Velocity torque/flux limit write failed"));
}

void MotorWorker::readRunStatusSnapshot(const QString &tag)
{
    ensureInterface();

    if (tmc == nullptr || !tmc->isOpen())
    {
        emit logMessage(QStringLiteral("RUN_STATUS[%1]: READ FAILED: serial port is not open").arg(tag));
        return;
    }

    if (tmc->isBusy())
    {
        emit logMessage(QStringLiteral("RUN_STATUS[%1]: SKIPPED: interface busy").arg(tag));
        return;
    }

    Tmc6460QtInterface::RunStatus s;
    if (!tmc->readRunStatus(&s))
    {
        const QString err = s.errorText.isEmpty() ? tmc->lastError() : s.errorText;
        emit logMessage(QStringLiteral("RUN_STATUS[%1]: READ FAILED: %2").arg(tag).arg(err));
        return;
    }

    emit statusReady(s);

    emit logMessage(QStringLiteral("RUN_STATUS[%1]: POS=0x%2 (%3), VEL_TARGET=%4, VEL_ACTUAL=%5, TORQUE_TARGET=%6, FLUX_TARGET=%7, TORQUE_ACTUAL=%8, FLUX_ACTUAL=%9, CURRENT_IQ=%10mA, RAW_TF_TARGET=0x%11, RAW_TF_ACTUAL=0x%12, STATUS=0x%13, EVENTS=0x%14, MOTION=0x%15, GDRV=0x%16")
                    .arg(tag)
                    .arg(s.positionActual, 8, 16, QLatin1Char('0')).toUpper()
                    .arg(s.positionActualSigned)
                    .arg(s.velocityTargetRaw)
                    .arg(s.velocityActualRaw)
                    .arg(s.torqueTargetRaw)
                    .arg(s.fluxTargetRaw)
                    .arg(s.torqueActualRaw)
                    .arg(s.fluxActualRaw)
                    .arg(s.torqueCurrentMilliAmp)
                    .arg(s.rawTorqueFluxTarget, 8, 16, QLatin1Char('0')).toUpper()
                    .arg(s.torqueFluxActual, 8, 16, QLatin1Char('0')).toUpper()
                    .arg(s.chipStatusFlags, 8, 16, QLatin1Char('0')).toUpper()
                    .arg(s.chipEvents, 8, 16, QLatin1Char('0')).toUpper()
                    .arg(s.motorMotion, 8, 16, QLatin1Char('0')).toUpper()
                    .arg(s.gdrv, 8, 16, QLatin1Char('0')).toUpper());
}

void MotorWorker::applyVelocityRaw(qint32 rawVelocity)
{
    ensureInterface();

    const qint32 limitedVelocity = qBound<qint32>(-MAX_ALLOWED_VELOCITY_RAW,
                                                  rawVelocity,
                                                  MAX_ALLOWED_VELOCITY_RAW);

    if (limitedVelocity != rawVelocity)
    {
        emit logMessage(QStringLiteral("SAFETY: Velocity command %1 clipped to %2")
                        .arg(rawVelocity)
                        .arg(limitedVelocity));
    }

    rawVelocity = limitedVelocity;

    if (!tmc->isOpen())
    {
        emit commandDone(QStringLiteral("Apply velocity target raw=%1").arg(rawVelocity), false);
        emit errorChanged(QStringLiteral("Cannot apply velocity: serial port is not open"));
        return;
    }

    if (rawVelocity != 0 && holdingAtEnd)
    {
        const int requestedDirection = (rawVelocity > 0) ? 1 : -1;
        if (requestedDirection == holdingDirection)
        {
            emit logMessage(QStringLiteral("IGNORED: Already holding at this end. Use opposite direction to move away. direction=%1")
                            .arg(holdingDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE")));
            emit commandDone(QStringLiteral("Velocity target raw=%1 ignored: already at this end").arg(rawVelocity), true);
            return;
        }

        holdingAtEnd = false;
        holdingDirection = 0;
    }

    if (rawVelocity == 0)
    {
        resetVelocityRampState();
        stopRunEndMonitor(true);

        const qint32 holdLimit = selectedHoldTorqueFluxLimitRaw();
        emit logMessage(QStringLiteral("MANUAL_ZERO_VELOCITY_HOLD: holdTorqueFluxLimit=%1, runningLimit=%2")
                        .arg(holdLimit)
                        .arg(activeVelocityTorqueFluxLimitRaw));

        const bool ok = tmc->safeLoadStopHold(holdLimit);
        emit commandDone(QStringLiteral("Velocity target raw=0 safe hold"), ok);
        if (!ok)
            emit errorChanged(QStringLiteral("Velocity zero safe hold failed"));
        return;
    }

#if TMC6460_ENABLE_VELOCITY_RAMP
    targetVelocityRaw = rawVelocity;

    if (!velocityRampTimer->isActive())
        velocityRampTimer->start();
#else
    resetVelocityRampState();

    const qint32 runLimit = selectedRunTorqueFluxLimitRawForDirection(rawVelocity);
    activeVelocityTorqueFluxLimitRaw = runLimit;

    emit logMessage(QStringLiteral("RUN_TORQUE_LIMIT_SELECTED: direction=%1, mode=%2, runTorqueFluxLimit=%3, holdTorqueFluxLimit=%4")
                    .arg(rawVelocity < 0 ? QStringLiteral("CCW_LIFT") : QStringLiteral("CW_RELEASE"))
#if TMC6460_USE_DIRECTION_RUN_TORQUE_LIMITS
                    .arg(QStringLiteral("DIRECTION_MACRO"))
#else
                    .arg(QStringLiteral("GUI"))
#endif
                    .arg(runLimit)
                    .arg(selectedHoldTorqueFluxLimitRaw()));

    if (!tmc->setVelocityTorqueFluxLimit(runLimit))
    {
        emit commandDone(QStringLiteral("Velocity torque/flux limit apply failed"), false);
        emit errorChanged(QStringLiteral("Velocity torque/flux limit write failed before run"));
        return;
    }

    const bool ok = writeVelocityRaw(rawVelocity);
    if (ok)
    {
        currentCommandedVelocityRaw = rawVelocity;
        startRunEndMonitor(rawVelocity);
    }

    emit commandDone(QStringLiteral("Velocity target raw=%1 direct").arg(rawVelocity), ok);
    if (!ok)
        emit errorChanged(QStringLiteral("Velocity direct write failed"));
#endif
}

void MotorWorker::processVelocityRamp()
{
    ensureInterface();

    if (!tmc->isOpen())
    {
        velocityRampTimer->stop();
        return;
    }

    if (currentCommandedVelocityRaw == targetVelocityRaw)
    {
        velocityRampTimer->stop();
        startRunEndMonitor(currentCommandedVelocityRaw);
        emit commandDone(QStringLiteral("Velocity reached raw=%1").arg(currentCommandedVelocityRaw), true);
        return;
    }

    qint32 nextRaw = currentCommandedVelocityRaw;

    if (currentCommandedVelocityRaw < targetVelocityRaw)
    {
        nextRaw += VELOCITY_RAMP_STEP_RAW;
        if (nextRaw > targetVelocityRaw)
            nextRaw = targetVelocityRaw;
    }
    else
    {
        nextRaw -= VELOCITY_RAMP_STEP_RAW;
        if (nextRaw < targetVelocityRaw)
            nextRaw = targetVelocityRaw;
    }

    if (!writeVelocityRaw(nextRaw))
    {
        velocityRampTimer->stop();
        stopRunEndMonitor(false);
        emit commandDone(QStringLiteral("Velocity ramp failed at raw=%1").arg(nextRaw), false);
        emit errorChanged(QStringLiteral("Velocity ramp write failed"));
        return;
    }

    currentCommandedVelocityRaw = nextRaw;

    if (currentCommandedVelocityRaw == targetVelocityRaw)
    {
        velocityRampTimer->stop();
        startRunEndMonitor(currentCommandedVelocityRaw);
        emit commandDone(QStringLiteral("Velocity reached raw=%1").arg(currentCommandedVelocityRaw), true);
    }
}

bool MotorWorker::writeVelocityRaw(qint32 rawVelocity)
{
    const bool ok = tmc->setVelocityTarget(rawVelocity);

    if (!ok)
    {
        emit logMessage(QStringLiteral("Velocity write failed at raw=%1").arg(rawVelocity));
    }

    return ok;
}

void MotorWorker::emergencyStop()
{
    ensureInterface();

    resetVelocityRampState();
    stopRunEndMonitor(true);

    const qint32 holdLimit = selectedHoldTorqueFluxLimitRaw();

    emit logMessage(QStringLiteral("SAFE_ESTOP: velocity-zero hold, driver enabled, holdTorqueFluxLimit=%1. Do not power off until load is mechanically safe.")
                    .arg(holdLimit));

    const bool ok = tmc->isOpen() && tmc->safeLoadStopHold(holdLimit);

    if (ok)
    {
        holdingAtEnd = true;
        emit stallStateChanged(true, QStringLiteral("SAFE E-STOP HOLD"));
    }
    else
    {
        emit errorChanged(QStringLiteral("SAFE E-STOP HOLD failed. Mechanically support the load before disabling power."));
    }

    emit commandDone(QStringLiteral("SAFE E-STOP HOLD"), ok);
}

void MotorWorker::shutdown()
{
    resetVelocityRampState();
    stopRunEndMonitor(true);

    if (tmc != nullptr)
    {
        if (tmc->isOpen())
        {
            emit logMessage(QStringLiteral("ACTION: GUI closing, safe motor shutdown requested"));
            const bool ok = tmc->shutdownMotorSafe();
            emit commandDone(QStringLiteral("GUI close shutdown"), ok);
        }

        tmc->closePort();
    }
}

void MotorWorker::resetVelocityRampState()
{
    if (velocityRampTimer != nullptr)
        velocityRampTimer->stop();

    currentCommandedVelocityRaw = 0;
    targetVelocityRaw = 0;
}

void MotorWorker::resetTorqueLogStats()
{
    runMinTorqueRaw = 0;
    runMaxTorqueRaw = 0;
    runMaxAbsTorqueRaw = 0;
    runMaxCurrentMilliAmp = 0;
    runSampleCount = 0;
}

void MotorWorker::updateTorqueLogStats(const Tmc6460QtInterface::RunStatus &status)
{
    if (runSampleCount == 0)
    {
        runMinTorqueRaw = status.torqueActualRaw;
        runMaxTorqueRaw = status.torqueActualRaw;
        runMaxAbsTorqueRaw = static_cast<qint16>(qAbs(status.torqueActualRaw));
        runMaxCurrentMilliAmp = qAbs(status.torqueCurrentMilliAmp);
    }
    else
    {
        if (status.torqueActualRaw < runMinTorqueRaw)
            runMinTorqueRaw = status.torqueActualRaw;
        if (status.torqueActualRaw > runMaxTorqueRaw)
            runMaxTorqueRaw = status.torqueActualRaw;
        if (qAbs(status.torqueActualRaw) > runMaxAbsTorqueRaw)
            runMaxAbsTorqueRaw = static_cast<qint16>(qAbs(status.torqueActualRaw));
        if (qAbs(status.torqueCurrentMilliAmp) > runMaxCurrentMilliAmp)
            runMaxCurrentMilliAmp = qAbs(status.torqueCurrentMilliAmp);
    }

    ++runSampleCount;
}

void MotorWorker::logTorqueSummary(const QString &tag,
                                   const Tmc6460QtInterface::RunStatus &status,
                                   qint64 travelCounts)
{
    emit logMessage(QStringLiteral("TORQUE_SUMMARY[%1]: samples=%2, travelCounts=%3, minTorqueRaw=%4, maxTorqueRaw=%5, maxAbsTorqueRaw=%6, maxIqCurrent=%7mA, finalTorqueRaw=%8, finalFluxRaw=%9, finalIqCurrent=%10mA")
                    .arg(tag)
                    .arg(runSampleCount)
                    .arg(travelCounts)
                    .arg(runMinTorqueRaw)
                    .arg(runMaxTorqueRaw)
                    .arg(runMaxAbsTorqueRaw)
                    .arg(runMaxCurrentMilliAmp)
                    .arg(status.torqueActualRaw)
                    .arg(status.fluxActualRaw)
                    .arg(status.torqueCurrentMilliAmp));
}

void MotorWorker::startRunEndMonitor(qint32 rawVelocity)
{
#if TMC6460_ENABLE_ACTUATOR_STOP_DETECTION
    if (qAbs(static_cast<qint64>(rawVelocity)) < CAL_MIN_TARGET_RAW)
    {
        stopRunEndMonitor(true);
        return;
    }

    runMonitorActive = true;
    stopLatched = false;
    startPositionValid = false;
    directionLearned = false;
    targetVelocityForMonitorRaw = rawVelocity;
    commandDirection = (rawVelocity > 0) ? 1 : -1;
    positionDirection = 0;
    startPositionRaw = 0;
    previousPositionRaw = 0;
    progressCounts = 0;
    blockedSamples = 0;
    resetTorqueLogStats();
    runTimer.restart();

    emit stallStateChanged(false, QStringLiteral("Monitoring velocity run to hard end"));
    emit logMessage(QStringLiteral("RUN_TO_END_START: command=%1, targetRaw=%2, torqueLimitRaw=%3, currentThreshold=%4mA, torqueThresholdRaw=%5, noProgressCounts=%6")
                    .arg(commandDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE"))
                    .arg(targetVelocityForMonitorRaw)
                    .arg(activeVelocityTorqueFluxLimitRaw)
                    .arg(TMC6460_END_DETECT_CURRENT_MA_THRESHOLD)
                    .arg(TMC6460_END_DETECT_TORQUE_RAW_THRESHOLD)
                    .arg(TMC6460_END_DETECT_NO_PROGRESS_COUNTS));
    emit logMessage(QStringLiteral("RUN_RULE: run at UI velocity until hard end/stall. Current/torque spike while still moving is logged, not stopped. Stop = moved + no position progress + low velocity; torque/current confirmation is macro controlled."));
#else
    Q_UNUSED(rawVelocity)
#endif
}

void MotorWorker::stopRunEndMonitor(bool clearGuiStatus)
{
    runMonitorActive = false;
    stopLatched = false;
    startPositionValid = false;
    directionLearned = false;
    targetVelocityForMonitorRaw = 0;
    commandDirection = 0;
    positionDirection = 0;
    startPositionRaw = 0;
    previousPositionRaw = 0;
    progressCounts = 0;
    blockedSamples = 0;

    if (clearGuiStatus)
        emit stallStateChanged(false, QStringLiteral("Not active"));
}

qint64 MotorWorker::signedPositionDelta32(quint32 current, quint32 start)
{
    const quint32 delta = current - start;
    return static_cast<qint32>(delta);
}

void MotorWorker::checkRunEndStop(const Tmc6460QtInterface::RunStatus &status)
{
    if (!runMonitorActive || stopLatched)
        return;

    updateTorqueLogStats(status);

    if (!startPositionValid)
    {
        startPositionRaw = status.positionActual;
        previousPositionRaw = status.positionActual;
        startPositionValid = true;
        runTimer.restart();

        emit logMessage(QStringLiteral("RUN_START_POSITION: command=%1, POS=%2 (%3), velCmd=%4, torque=%5, flux=%6, currentIq=%7mA")
                        .arg(commandDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE"))
                        .arg(hex32(status.positionActual))
                        .arg(status.positionActualSigned)
                        .arg(targetVelocityForMonitorRaw)
                        .arg(status.torqueActualRaw)
                        .arg(status.fluxActualRaw)
                        .arg(status.torqueCurrentMilliAmp));
        return;
    }

    const qint64 deltaFromStart = signedPositionDelta32(status.positionActual, startPositionRaw);
    const qint64 deltaFromPrevious = signedPositionDelta32(status.positionActual, previousPositionRaw);
    const qint64 absDeltaFromPrevious = qAbs(deltaFromPrevious);

    if (!directionLearned && qAbs(deltaFromStart) >= TMC6460_END_DETECT_MIN_TRAVEL_COUNTS)
    {
        directionLearned = true;
        positionDirection = (deltaFromStart >= 0) ? 1 : -1;

        emit logMessage(QStringLiteral("RUN_DIRECTION_LEARNED: command=%1, positionDirection=%2, start=%3, current=%4, delta=%5")
                        .arg(commandDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE"))
                        .arg(positionDirection > 0 ? QStringLiteral("INCREASING") : QStringLiteral("DECREASING"))
                        .arg(hex32(startPositionRaw))
                        .arg(hex32(status.positionActual))
                        .arg(deltaFromStart));
    }

    progressCounts = qAbs(deltaFromStart);

    const qint64 targetAbs = qAbs(static_cast<qint64>(targetVelocityForMonitorRaw));
    const qint64 actualAbs = qAbs(static_cast<qint64>(status.velocityActualRaw));
    const qint64 lowVelocityLimit = qMax<qint64>(TMC6460_END_DETECT_LOW_VELOCITY_RAW,
                                                (targetAbs * TMC6460_END_DETECT_LOW_VELOCITY_RATIO_PERCENT) / 100LL);

    const bool startupSettled = runTimer.isValid() &&
                                runTimer.elapsed() >= TMC6460_END_DETECT_STARTUP_IGNORE_MS;
    const bool actuatorHasMoved = progressCounts >= TMC6460_END_DETECT_MIN_TRAVEL_COUNTS;
    const bool positionStopped = absDeltaFromPrevious <= TMC6460_END_DETECT_NO_PROGRESS_COUNTS;
    const bool velocityLow = actualAbs <= lowVelocityLimit;
    const bool torqueLoaded = qAbs(status.torqueActualRaw) >= TMC6460_END_DETECT_TORQUE_RAW_THRESHOLD;
    const bool currentLoaded = qAbs(status.torqueCurrentMilliAmp) >= TMC6460_END_DETECT_CURRENT_MA_THRESHOLD;
#if TMC6460_END_DETECT_REQUIRE_TORQUE_OR_CURRENT
    const bool loadConfirmOk = (torqueLoaded || currentLoaded);
#else
    const bool loadConfirmOk = true;
#endif

    const bool possibleHardEnd = startupSettled && actuatorHasMoved && positionStopped && velocityLow && loadConfirmOk;

#if TMC6460_TORQUE_LOG_EVERY_SAMPLE
    emit logMessage(QStringLiteral("TORQUE_LOG_SAMPLE: command=%1, tMs=%2, POS=%3 (%4), travel=%5, deltaSample=%6, velCmd=%7, velActual=%8, torqueRaw=%9, fluxRaw=%10, currentIq=%11mA, posStopped=%12, velocityLow=%13, torqueLoaded=%14, currentLoaded=%15, blockedSamples=%16")
                    .arg(commandDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE"))
                    .arg(runTimer.isValid() ? runTimer.elapsed() : 0)
                    .arg(hex32(status.positionActual))
                    .arg(status.positionActualSigned)
                    .arg(progressCounts)
                    .arg(deltaFromPrevious)
                    .arg(targetVelocityForMonitorRaw)
                    .arg(status.velocityActualRaw)
                    .arg(status.torqueActualRaw)
                    .arg(status.fluxActualRaw)
                    .arg(status.torqueCurrentMilliAmp)
                    .arg(positionStopped ? 1 : 0)
                    .arg(velocityLow ? 1 : 0)
                    .arg(torqueLoaded ? 1 : 0)
                    .arg(currentLoaded ? 1 : 0)
                    .arg(blockedSamples));
#endif

    if (runTimer.isValid() && runTimer.elapsed() >= TMC6460_END_DETECT_SAFETY_TIMEOUT_MS)
    {
        handleRunEndStop(QStringLiteral("SAFETY_TIMEOUT"), status, progressCounts);
        return;
    }

    if (!startupSettled || !actuatorHasMoved)
    {
        previousPositionRaw = status.positionActual;
        blockedSamples = 0;
        return;
    }

    if (possibleHardEnd)
    {
        ++blockedSamples;
        if (blockedSamples >= TMC6460_END_DETECT_BLOCKED_SAMPLES)
        {
            handleRunEndStop(QStringLiteral("HARD_END_OR_STALL"), status, progressCounts);
            return;
        }
    }
    else
    {
        blockedSamples = 0;
    }

    previousPositionRaw = status.positionActual;
}

void MotorWorker::handleRunEndStop(const QString &reason,
                                   const Tmc6460QtInterface::RunStatus &status,
                                   qint64 travelCounts)
{
    stopLatched = true;
    runMonitorActive = false;
    resetVelocityRampState();

    const int endedCommandDirection = commandDirection;
    const quint32 detectedEndPosition = status.positionActual;
    const qint32 holdLimit = selectedHoldTorqueFluxLimitRaw();

    logTorqueSummary(reason, status, travelCounts);

    emit logMessage(QStringLiteral("RUN_END_%1: command=%2, startPos=%3, endPos=%4 (%5), travelCounts=%6, velActual=%7, torqueRaw=%8, fluxRaw=%9, currentIq=%10mA, holdTorqueFluxLimit=%11, runTorqueFluxLimit=%12, status=%13, events=%14")
                    .arg(reason)
                    .arg(endedCommandDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE"))
                    .arg(hex32(startPositionRaw))
                    .arg(hex32(detectedEndPosition))
                    .arg(status.positionActualSigned)
                    .arg(travelCounts)
                    .arg(status.velocityActualRaw)
                    .arg(status.torqueActualRaw)
                    .arg(status.fluxActualRaw)
                    .arg(status.torqueCurrentMilliAmp)
                    .arg(holdLimit)
                    .arg(activeVelocityTorqueFluxLimitRaw)
                    .arg(hex32(status.chipStatusFlags))
                    .arg(hex32(status.chipEvents)));

    holdingAtEnd = true;
    holdingDirection = (endedCommandDirection >= 0) ? 1 : -1;

    bool ok = false;
    if (tmc != nullptr && tmc->isOpen())
        ok = tmc->safeLoadStopHold(holdLimit);

    emit stallStateChanged(true,
                           ok ? QStringLiteral("END/STALL FOUND - safe hold applied")
                              : QStringLiteral("END/STALL FOUND - hold command failed"));

    if (tmc != nullptr && tmc->isOpen() && !tmc->isBusy())
    {
        Tmc6460QtInterface::RunStatus settled;
        if (tmc->readRunStatus(&settled))
        {
            emit logMessage(QStringLiteral("RUN_SETTLED_END: command=%1, POS=%2 (%3), VEL_TARGET=%4, VEL_ACTUAL=%5, TORQUE_ACTUAL=%6, FLUX_ACTUAL=%7, CURRENT_IQ=%8mA, STATUS=%9, EVENTS=%10")
                            .arg(endedCommandDirection > 0 ? QStringLiteral("CW_POSITIVE") : QStringLiteral("CCW_NEGATIVE"))
                            .arg(hex32(settled.positionActual))
                            .arg(settled.positionActualSigned)
                            .arg(settled.velocityTargetRaw)
                            .arg(settled.velocityActualRaw)
                            .arg(settled.torqueActualRaw)
                            .arg(settled.fluxActualRaw)
                            .arg(settled.torqueCurrentMilliAmp)
                            .arg(hex32(settled.chipStatusFlags))
                            .arg(hex32(settled.chipEvents)));
        }
    }
}

QString MotorWorker::hex32(quint32 value)
{
    return QStringLiteral("0x%1").arg(value, 8, 16, QLatin1Char('0')).toUpper();
}
