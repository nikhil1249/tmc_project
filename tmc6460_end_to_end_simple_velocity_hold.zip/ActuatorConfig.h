#ifndef ACTUATORCONFIG_H
#define ACTUATORCONFIG_H

/*
 * TMC6460 actuator configuration - SIMPLE VELOCITY MODE ONLY.
 *
 * Scenario:
 *   CCW = lift load.
 *   CW  = release/lower load.
 *
 * Manual operation:
 *   Click CCW -> actuator runs at UI velocity until hard end/stall, then holds.
 *   Click CW  -> actuator runs at UI velocity until hard end/stall, then holds.
 *
 * No auto-calibration, no auto-reverse, no position target mode, no torque mode.
 * POSITION_ACTUAL is read only as feedback for end/stall detection.
 */

/* Master mode switches. Keep both disabled for this build. */
#define TMC6460_ENABLE_TORQUE_MODE                         0
#define TMC6460_ENABLE_POSITION_MODE                       0

/* Direction definition for logs only. It does not change command signs. */
#define TMC6460_CCW_IS_LIFT_DIRECTION                      1

/*
 * Single default torque/flux limit macro.
 * GUI Velocity Torque/Flux Limit defaults to this value and writes both
 * torque limit and flux limit to FOC_PID_TORQUE_FLUX_LIMITS.
 */
#define DEFAULT_VELOCITY_TORQUE_LIMIT_RAW                  3000
#define MIN_VELOCITY_TORQUE_LIMIT_RAW                      300
#define MAX_VELOCITY_TORQUE_LIMIT_RAW                      6000

/*
 * Optional direction-specific run torque limits.
 * 0 = use GUI torque/flux limit for both CW and CCW.
 * 1 = override GUI limit depending on direction.
 *
 * For your mechanism:
 *   CCW lifts the load, so it may need higher run torque.
 *   CW releases/lowers the load, so it can use lower run torque if required.
 */
#define TMC6460_USE_DIRECTION_RUN_TORQUE_LIMITS            0
#define TMC6460_CCW_LIFT_RUN_TORQUE_FLUX_LIMIT_RAW         4000
#define TMC6460_CW_RELEASE_RUN_TORQUE_FLUX_LIMIT_RAW       2500

/* End/stall monitor. */
#define TMC6460_ENABLE_ACTUATOR_STOP_DETECTION             1
#define TMC6460_TORQUE_LOG_EVERY_SAMPLE                    1

/*
 * Hard-end/stall detection rule.
 * The code should not stop only because current/torque rises while the actuator
 * is still moving. It stops when the actuator has moved, then position stops
 * changing and actual velocity collapses. Torque/current thresholds can be used
 * as an additional confirmation if enabled.
 */
#define TMC6460_END_DETECT_REQUIRE_TORQUE_OR_CURRENT       0

/*
 * Detection tuning.
 * To stop faster after real hard end, reduce BLOCKED_SAMPLES.
 * To avoid early false stops, increase BLOCKED_SAMPLES or MIN_TRAVEL_COUNTS.
 */
#define TMC6460_END_DETECT_STARTUP_IGNORE_MS               700
#define TMC6460_END_DETECT_MIN_TRAVEL_COUNTS               50000LL
#define TMC6460_END_DETECT_NO_PROGRESS_COUNTS              300LL
#define TMC6460_END_DETECT_LOW_VELOCITY_RAW                70000
#define TMC6460_END_DETECT_LOW_VELOCITY_RATIO_PERCENT      8
#define TMC6460_END_DETECT_TORQUE_RAW_THRESHOLD            80
#define TMC6460_END_DETECT_CURRENT_MA_THRESHOLD            80
#define TMC6460_END_DETECT_BLOCKED_SAMPLES                 1
#define TMC6460_END_DETECT_SAFETY_TIMEOUT_MS               30000

/*
 * Hold after end/stall/E-stop/manual velocity 0.
 * 0 = use dedicated limited hold torque below.
 * 1 = use currently selected GUI run torque/flux limit for holding.
 *
 * For gear safety, keep dedicated hold torque as low as possible but high enough
 * that the 10 kg load does not back-drive.
 */
#define TMC6460_HOLD_USES_RUNNING_TORQUE_LIMIT             0
#define TMC6460_END_HOLD_TORQUE_FLUX_LIMIT_RAW             1200
#define TMC6460_SAFE_ESTOP_HOLD_TORQUE_FLUX_LIMIT_RAW      1200

#endif // ACTUATORCONFIG_H
