QT += core gui serialport

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

TARGET = tmc6460_qt_complete
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp \
    MotorWorker.cpp \
    Tmc6460QtInterface.cpp \
    TMC6460.c

HEADERS += \
    ActuatorConfig.h \
    mainwindow.h \
    MotorWorker.h \
    Tmc6460QtInterface.h \
    TMC6460.h \
    TMC6460_HW_Abstraction.h

FORMS += \
    mainwindow.ui
