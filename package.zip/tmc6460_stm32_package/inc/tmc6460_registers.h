#ifndef TMC6460_REGISTERS_H
#define TMC6460_REGISTERS_H

#include <stdint.h>

/*
 * TMC6460 register addresses used in the existing Qt/Arduino project.
 * Keep all raw addresses in this file so the application layer never uses
 * magic numbers directly.
 */

#define TMC6460_REG_CHIP_ID                         0x0000u
#define TMC6460_REG_CHIP_VARIANT                    0x0001u
#define TMC6460_REG_CHIP_REVISION                   0x0002u
#define TMC6460_REG_CHIP_STATUS_FLAGS               0x0004u
#define TMC6460_REG_CHIP_EVENTS                     0x0005u
#define TMC6460_REG_CHIP_IO_CONFIG                  0x0008u

#define TMC6460_REG_MCC_ADC_CSA_GAIN                0x00C3u

#define TMC6460_REG_MCC_CONFIG_MOTOR_MOTION         0x0100u
#define TMC6460_REG_MCC_CONFIG_GDRV                 0x0101u
#define TMC6460_REG_MCC_CONFIG_PWM                  0x0102u

#define TMC6460_REG_FOC_PID_CONFIG                  0x0140u
#define TMC6460_REG_FOC_PID_FLUX_COEFF              0x0142u
#define TMC6460_REG_FOC_PID_TORQUE_COEFF            0x0143u
#define TMC6460_REG_FOC_PID_VELOCITY_COEFF          0x0145u
#define TMC6460_REG_FOC_UQ_UD_LIMITS                0x0149u
#define TMC6460_REG_FOC_TORQUE_FLUX_LIMITS          0x014Au
#define TMC6460_REG_FOC_VELOCITY_LIMITS             0x014Bu
#define TMC6460_REG_FOC_TORQUE_TARGET               0x014Eu
#define TMC6460_REG_FOC_FLUX_TARGET                 0x014Fu
#define TMC6460_REG_FOC_VELOCITY_TARGET             0x0150u
#define TMC6460_REG_FOC_POSITION_TARGET             0x0151u

#define TMC6460_REG_FOC_VELOCITY_ACTUAL             0x0154u
#define TMC6460_REG_FOC_POSITION_ACTUAL             0x0155u
#define TMC6460_REG_FOC_TORQUE_ACTUAL               0x0156u
#define TMC6460_REG_FOC_FLUX_ACTUAL                 0x0157u

#define TMC6460_REG_MCC_FEEDBACK_CONFIG_CH_A        0x0240u
#define TMC6460_REG_MCC_FEEDBACK_CONFIG_CH_B        0x0241u
#define TMC6460_REG_MCC_FEEDBACK_CONFIG_VELOCITY    0x0242u

#define TMC6460_REG_HALL_MAP_CONFIG                 0x0300u

/* Values captured from the currently working Qt/Arduino velocity setup. */
#define TMC6460_VAL_CHIP_IO_CONFIG_DEFAULT          0x70055038ul
#define TMC6460_VAL_ADC_CSA_GAIN_DEFAULT            0x00000005ul
#define TMC6460_VAL_MOTOR_MOTION_VELOCITY           0x0000E586ul
#define TMC6460_VAL_GDRV_DISABLE                    0x80003431ul
#define TMC6460_VAL_GDRV_ENABLE                     0x80013431ul
#define TMC6460_VAL_PWM_CONFIG_DEFAULT              0x00000017ul
#define TMC6460_VAL_FOC_PID_CONFIG_DEFAULT          0x00008558ul
#define TMC6460_VAL_FOC_PID_FLUX_COEFF_DEFAULT      0x01E54C51ul
#define TMC6460_VAL_FOC_PID_TORQUE_COEFF_DEFAULT    0x01E54C51ul
#define TMC6460_VAL_FOC_PID_VELOCITY_COEFF_DEFAULT  0x00640000ul
#define TMC6460_VAL_FOC_UQ_UD_LIMITS_DEFAULT        0x00001AAAul
#define TMC6460_VAL_FOC_TORQUE_FLUX_LIMITS_DEFAULT  0x13881388ul
#define TMC6460_VAL_FOC_VELOCITY_LIMITS_DEFAULT     0x003D0900ul
#define TMC6460_VAL_FEEDBACK_CH_A_DEFAULT           0x052AAAABul
#define TMC6460_VAL_FEEDBACK_CH_B_DEFAULT           0x06004000ul
#define TMC6460_VAL_FEEDBACK_VELOCITY_DEFAULT       0x00001000ul

/* CHIP_STATUS_FLAGS masks used by the monitoring layer. Verify against the
 * final datasheet/register map before production release.
 */
#define TMC6460_STATUS_GDRV_ON_STATE_MASK           (1ul << 30)
#define TMC6460_STATUS_SYS_READY_STATE_MASK         (1ul << 31)
#define TMC6460_STATUS_OVERTEMP_WARN_MASK           (1ul << 23)
#define TMC6460_STATUS_OV_VM_LIMIT_FAIL_MASK        (1ul << 22)
#define TMC6460_STATUS_VM_TEMP_CLIPPED_MASK         (1ul << 20)
#define TMC6460_STATUS_AIN_CLIPPED_MASK             (1ul << 19)
#define TMC6460_STATUS_I_CLIPPED_MASK               (1ul << 18)

#endif /* TMC6460_REGISTERS_H */
