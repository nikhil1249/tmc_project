#ifndef TMC6460_H
#define TMC6460_H

#include <stdint.h>
#include <stdbool.h>
#include "tmc6460_port.h"
#include "tmc6460_registers.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    TMC6460_OK = 0,
    TMC6460_ERROR = -1,
    TMC6460_TIMEOUT = -2,
    TMC6460_BAD_PARAMETER = -3,
    TMC6460_NOT_INITIALIZED = -4
} TMC6460_Status_t;

typedef enum
{
    TMC6460_MODE_DISABLED = 0,
    TMC6460_MODE_VELOCITY,
    TMC6460_MODE_TORQUE,
    TMC6460_MODE_POSITION
} TMC6460_ControlMode_t;

typedef struct
{
    uint32_t chipIoConfig;
    uint32_t adcCsaGain;
    uint32_t motorMotionVelocity;
    uint32_t gdrvDisable;
    uint32_t gdrvEnable;
    uint32_t pwmConfig;
    uint32_t focPidConfig;
    uint32_t focPidFluxCoeff;
    uint32_t focPidTorqueCoeff;
    uint32_t focPidVelocityCoeff;
    uint32_t uqUdLimits;
    uint32_t torqueFluxLimits;
    uint32_t velocityLimits;
    uint32_t feedbackChA;
    uint32_t feedbackChB;
    uint32_t feedbackVelocity;
    uint32_t defaultTorqueTarget;
    uint32_t defaultVelocityTarget;
} TMC6460_Config_t;

typedef struct
{
    uint32_t chipId;
    uint32_t statusFlags;
    int32_t velocityActual;
    int32_t positionActual;
    int32_t torqueActual;
    int32_t fluxActual;
    bool driverEnabled;
    bool systemReady;
    bool faultPresent;
    bool stallDetected;
} TMC6460_Feedback_t;

typedef struct
{
    int32_t minAbsVelocityRaw;
    int32_t minAbsPositionDeltaRaw;
    int32_t maxAbsPositionDeltaRaw;
    int32_t minAbsTorqueRaw;
    uint32_t detectionTimeMs;
    bool enabled;
} TMC6460_StallConfig_t;

typedef struct
{
    TMC6460_Config_t config;
    TMC6460_Feedback_t feedback;
    TMC6460_StallConfig_t stallConfig;
    TMC6460_ControlMode_t mode;
    int32_t targetVelocity;
    int32_t targetTorque;
    int32_t targetPosition;
    int32_t previousPosition;
    uint32_t stallStartTimeMs;
    bool initialized;
} TMC6460_Handle_t;

void TMC6460_GetDefaultConfig(TMC6460_Config_t *config);
void TMC6460_GetDefaultStallConfig(TMC6460_StallConfig_t *config);

TMC6460_Status_t TMC6460_Init(TMC6460_Handle_t *handle, const TMC6460_Config_t *config);
TMC6460_Status_t TMC6460_DeInit(TMC6460_Handle_t *handle);
TMC6460_Status_t TMC6460_Configure(TMC6460_Handle_t *handle);
TMC6460_Status_t TMC6460_ReadChipId(TMC6460_Handle_t *handle, uint32_t *chipId);
TMC6460_Status_t TMC6460_EnableDriver(TMC6460_Handle_t *handle);
TMC6460_Status_t TMC6460_DisableDriver(TMC6460_Handle_t *handle);
TMC6460_Status_t TMC6460_EStop(TMC6460_Handle_t *handle);

TMC6460_Status_t TMC6460_SetVelocityMode(TMC6460_Handle_t *handle);
TMC6460_Status_t TMC6460_SetVelocity(TMC6460_Handle_t *handle, int32_t velocityRaw);
TMC6460_Status_t TMC6460_SetTorqueTarget(TMC6460_Handle_t *handle, int32_t torqueRaw);
TMC6460_Status_t TMC6460_SetTorqueLimit(TMC6460_Handle_t *handle, uint16_t torqueLimitRaw, uint16_t fluxLimitRaw);
TMC6460_Status_t TMC6460_SetVelocityLimit(TMC6460_Handle_t *handle, uint32_t velocityLimitRaw);
TMC6460_Status_t TMC6460_SetPositionTarget(TMC6460_Handle_t *handle, int32_t positionRaw);

TMC6460_Status_t TMC6460_ReadFeedback(TMC6460_Handle_t *handle, TMC6460_Feedback_t *feedback);
TMC6460_Status_t TMC6460_ReadStatusFlags(TMC6460_Handle_t *handle, uint32_t *statusFlags);
TMC6460_Status_t TMC6460_Task(TMC6460_Handle_t *handle);

TMC6460_Status_t TMC6460_WriteReg(uint16_t address, uint32_t value);
TMC6460_Status_t TMC6460_ReadReg(uint16_t address, uint32_t *value);

#ifdef __cplusplus
}
#endif

#endif /* TMC6460_H */
