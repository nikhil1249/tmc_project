#ifndef TMC6460_PORT_H
#define TMC6460_PORT_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    TMC6460_PORT_OK = 0,
    TMC6460_PORT_ERROR = -1,
    TMC6460_PORT_TIMEOUT = -2,
    TMC6460_PORT_BAD_CRC = -3,
    TMC6460_PORT_BAD_PARAMETER = -4
} TMC6460_PortStatus_t;

/*
 * MCU/board specific functions.
 * Implement these using STM32 HAL/LL UART, SPI, or another transport.
 * The generic driver calls only these functions for hardware access.
 */
TMC6460_PortStatus_t TMC6460_Port_Init(void);
TMC6460_PortStatus_t TMC6460_Port_DeInit(void);
TMC6460_PortStatus_t TMC6460_Port_WriteRegister(uint16_t address, uint32_t value);
TMC6460_PortStatus_t TMC6460_Port_ReadRegister(uint16_t address, uint32_t *value);
void TMC6460_Port_DelayMs(uint32_t delay_ms);
uint32_t TMC6460_Port_GetTickMs(void);

#ifdef __cplusplus
}
#endif

#endif /* TMC6460_PORT_H */
