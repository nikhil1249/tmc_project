# TMC6460 Qt to STM32 Migration Package

This package contains a generic, modular STM32-ready TMC6460 driver based on the working Qt/Arduino UART approach.

## Ready files to add to STM32 project

Add these files to STM32CubeIDE / Keil / IAR:

```text
inc/tmc6460.h
inc/tmc6460_port.h
inc/tmc6460_registers.h
src/tmc6460.c
src/tmc6460_port_stm32_hal.c
src/tmc6460_app_example.c   optional test/example
```

Do **not** compile `src/tmc6460_port_stm32_template.c`; it is only a note file.

## STM32 HAL UART port

`src/tmc6460_port_stm32_hal.c` now contains the Arduino-equivalent UART protocol migrated to STM32 HAL:

```c
HAL_UART_Transmit(&huart1, tx, len, 150);
HAL_UART_Receive(&huart1, rx, len, 150);
```

Default UART handle is `huart1`. To use another UART, add compiler define:

```text
-DTMC6460_STM32_UART_HANDLE=huart2
```

Also ensure `USE_STM32_HAL` is defined in your STM32 build.

## UART frame used

Read register:

```text
TX 2 bytes: [0x42 | (((address >> 8) & 0x03) << 4), address_low]
RX 6 bytes: [same_header, same_address_low, data_msb, data, data, data_lsb]
```

Write register:

```text
TX 6 bytes: [0x4A | (((address >> 8) & 0x03) << 4), address_low, data_msb, data, data, data_lsb]
```

Validation read:

```text
TMC6460_REG_CHIP_ID / address 0x0000 should return 0x36343630
```

## Connection

```text
STM32 UART_TX -> TMC6460 UART_RX
STM32 UART_RX <- TMC6460 UART_TX
STM32 GND     -> TMC6460 GND
Baud          -> 115200, 8-N-1
```

## Application layer usage

Use high-level calls from `tmc6460.h`:

```c
TMC6460_Handle_t h;
TMC6460_Init(&h, NULL);
TMC6460_EnableDriver(&h);
TMC6460_SetVelocity(&h, 250000);
TMC6460_SetTorqueTarget(&h, 300);
TMC6460_Task(&h);
TMC6460_EStop(&h);
```

## Reference

`src/arduino_uart_reference_snippet.c` contains the Arduino Due `Serial1` read/write logic as a disabled `#if 0` reference block.
