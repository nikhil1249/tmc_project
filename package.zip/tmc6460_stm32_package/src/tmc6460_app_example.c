#include "tmc6460.h"

static TMC6460_Handle_t g_tmc6460;

void MotorApp_Init(void)
{
    TMC6460_Config_t cfg;
    TMC6460_GetDefaultConfig(&cfg);

    /* Keep velocity mode as the operating mode. Set the default torque/current
     * command here if your test requires initial torque before moving.
     */
    cfg.defaultTorqueTarget = 0u;
    cfg.defaultVelocityTarget = 0u;

    if (TMC6460_Init(&g_tmc6460, &cfg) == TMC6460_OK)
    {
        (void)TMC6460_EnableDriver(&g_tmc6460);
    }
}

void MotorApp_1msOr10msTask(void)
{
    (void)TMC6460_Task(&g_tmc6460);

    if (g_tmc6460.feedback.stallDetected)
    {
        /* Safe reaction example. Tune for your actuator. */
        (void)TMC6460_EStop(&g_tmc6460);
    }
}

void MotorApp_SetVelocityRaw(int32_t velocityRaw)
{
    (void)TMC6460_SetVelocity(&g_tmc6460, velocityRaw);
}

void MotorApp_SetTorqueRaw(int32_t torqueRaw)
{
    (void)TMC6460_SetTorqueTarget(&g_tmc6460, torqueRaw);
}

void MotorApp_EStop(void)
{
    (void)TMC6460_EStop(&g_tmc6460);
}

const TMC6460_Feedback_t *MotorApp_GetFeedback(void)
{
    return &g_tmc6460.feedback;
}
