/*
 * This file is kept only for documentation compatibility with the first package.
 *
 * READY STM32 HAL IMPLEMENTATION IS IN:
 *     src/tmc6460_port_stm32_hal.c
 *
 * Do not compile this template file together with tmc6460_port_stm32_hal.c.
 * Add only these files to STM32CubeIDE / Keil / IAR project:
 *     src/tmc6460.c
 *     src/tmc6460_port_stm32_hal.c
 *     src/tmc6460_app_example.c       optional test application
 *     inc/tmc6460.h
 *     inc/tmc6460_port.h
 *     inc/tmc6460_registers.h
 */
