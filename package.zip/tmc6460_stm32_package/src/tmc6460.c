#include "tmc6460.h"
#include <string.h>
#include <stdlib.h>

static TMC6460_Status_t portToDriverStatus(TMC6460_PortStatus_t status)
{
    switch (status)
    {
        case TMC6460_PORT_OK: return TMC6460_OK;
        case TMC6460_PORT_TIMEOUT: return TMC6460_TIMEOUT;
        case TMC6460_PORT_BAD_PARAMETER: return TMC6460_BAD_PARAMETER;
        default: return TMC6460_ERROR;
    }
}

static bool isInitialized(const TMC6460_Handle_t *handle)
{
    return (handle != NULL) && handle->initialized;
}

static int32_t abs32(int32_t value)
{
    return (value < 0) ? -value : value;
}

void TMC6460_GetDefaultConfig(TMC6460_Config_t *config)
{
    if (config == NULL)
    {
        return;
    }

    config->chipIoConfig = TMC6460_VAL_CHIP_IO_CONFIG_DEFAULT;
    config->adcCsaGain = TMC6460_VAL_ADC_CSA_GAIN_DEFAULT;
    config->motorMotionVelocity = TMC6460_VAL_MOTOR_MOTION_VELOCITY;
    config->gdrvDisable = TMC6460_VAL_GDRV_DISABLE;
    config->gdrvEnable = TMC6460_VAL_GDRV_ENABLE;
    config->pwmConfig = TMC6460_VAL_PWM_CONFIG_DEFAULT;
    config->focPidConfig = TMC6460_VAL_FOC_PID_CONFIG_DEFAULT;
    config->focPidFluxCoeff = TMC6460_VAL_FOC_PID_FLUX_COEFF_DEFAULT;
    config->focPidTorqueCoeff = TMC6460_VAL_FOC_PID_TORQUE_COEFF_DEFAULT;
    config->focPidVelocityCoeff = TMC6460_VAL_FOC_PID_VELOCITY_COEFF_DEFAULT;
    config->uqUdLimits = TMC6460_VAL_FOC_UQ_UD_LIMITS_DEFAULT;
    config->torqueFluxLimits = TMC6460_VAL_FOC_TORQUE_FLUX_LIMITS_DEFAULT;
    config->velocityLimits = TMC6460_VAL_FOC_VELOCITY_LIMITS_DEFAULT;
    config->feedbackChA = TMC6460_VAL_FEEDBACK_CH_A_DEFAULT;
    config->feedbackChB = TMC6460_VAL_FEEDBACK_CH_B_DEFAULT;
    config->feedbackVelocity = TMC6460_VAL_FEEDBACK_VELOCITY_DEFAULT;
    config->defaultTorqueTarget = 0u;
    config->defaultVelocityTarget = 0u;
}

void TMC6460_GetDefaultStallConfig(TMC6460_StallConfig_t *config)
{
    if (config == NULL)
    {
        return;
    }

    config->enabled = true;
    config->minAbsVelocityRaw = 50;
    config->minAbsPositionDeltaRaw = 0;
    config->maxAbsPositionDeltaRaw = 10;
    config->minAbsTorqueRaw = 800;
    config->detectionTimeMs = 100;
}

TMC6460_Status_t TMC6460_WriteReg(uint16_t address, uint32_t value)
{
    return portToDriverStatus(TMC6460_Port_WriteRegister(address, value));
}

TMC6460_Status_t TMC6460_ReadReg(uint16_t address, uint32_t *value)
{
    if (value == NULL)
    {
        return TMC6460_BAD_PARAMETER;
    }
    return portToDriverStatus(TMC6460_Port_ReadRegister(address, value));
}

TMC6460_Status_t TMC6460_Init(TMC6460_Handle_t *handle, const TMC6460_Config_t *config)
{
    if (handle == NULL)
    {
        return TMC6460_BAD_PARAMETER;
    }

    memset(handle, 0, sizeof(*handle));

    if (config != NULL)
    {
        handle->config = *config;
    }
    else
    {
        TMC6460_GetDefaultConfig(&handle->config);
    }

    TMC6460_GetDefaultStallConfig(&handle->stallConfig);
    handle->mode = TMC6460_MODE_DISABLED;

    TMC6460_Status_t status = portToDriverStatus(TMC6460_Port_Init());
    if (status != TMC6460_OK)
    {
        return status;
    }

    handle->initialized = true;
    status = TMC6460_ReadChipId(handle, &handle->feedback.chipId);
    if (status != TMC6460_OK)
    {
        return status;
    }

    return TMC6460_Configure(handle);
}

TMC6460_Status_t TMC6460_DeInit(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    (void)TMC6460_DisableDriver(handle);
    handle->initialized = false;
    return portToDriverStatus(TMC6460_Port_DeInit());
}

TMC6460_Status_t TMC6460_Configure(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    const TMC6460_Config_t *cfg = &handle->config;

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_CHIP_IO_CONFIG, cfg->chipIoConfig);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_ADC_CSA_GAIN, cfg->adcCsaGain);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_CONFIG_MOTOR_MOTION, cfg->motorMotionVelocity);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_CONFIG_GDRV, cfg->gdrvDisable);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_CONFIG_PWM, cfg->pwmConfig);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_PID_CONFIG, cfg->focPidConfig);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_PID_FLUX_COEFF, cfg->focPidFluxCoeff);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_PID_TORQUE_COEFF, cfg->focPidTorqueCoeff);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_PID_VELOCITY_COEFF, cfg->focPidVelocityCoeff);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_UQ_UD_LIMITS, cfg->uqUdLimits);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_TORQUE_FLUX_LIMITS, cfg->torqueFluxLimits);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_FOC_VELOCITY_LIMITS, cfg->velocityLimits);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_FEEDBACK_CONFIG_CH_A, cfg->feedbackChA);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_FEEDBACK_CONFIG_CH_B, cfg->feedbackChB);
    if (status != TMC6460_OK) return status;

    status = TMC6460_WriteReg(TMC6460_REG_MCC_FEEDBACK_CONFIG_VELOCITY, cfg->feedbackVelocity);
    if (status != TMC6460_OK) return status;

    handle->mode = TMC6460_MODE_VELOCITY;
    handle->targetVelocity = (int32_t)cfg->defaultVelocityTarget;
    handle->targetTorque = (int32_t)cfg->defaultTorqueTarget;

    if (cfg->defaultTorqueTarget != 0u)
    {
        status = TMC6460_SetTorqueTarget(handle, (int32_t)cfg->defaultTorqueTarget);
        if (status != TMC6460_OK) return status;
    }

    if (cfg->defaultVelocityTarget != 0u)
    {
        status = TMC6460_SetVelocity(handle, (int32_t)cfg->defaultVelocityTarget);
        if (status != TMC6460_OK) return status;
    }

    return TMC6460_OK;
}

TMC6460_Status_t TMC6460_ReadChipId(TMC6460_Handle_t *handle, uint32_t *chipId)
{
    if ((handle == NULL) || (chipId == NULL))
    {
        return TMC6460_BAD_PARAMETER;
    }

    TMC6460_Status_t status = TMC6460_ReadReg(TMC6460_REG_CHIP_ID, chipId);
    if (status == TMC6460_OK)
    {
        handle->feedback.chipId = *chipId;
    }
    return status;
}

TMC6460_Status_t TMC6460_EnableDriver(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_MCC_CONFIG_GDRV, handle->config.gdrvEnable);
    if (status == TMC6460_OK)
    {
        handle->feedback.driverEnabled = true;
    }
    return status;
}

TMC6460_Status_t TMC6460_DisableDriver(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_MCC_CONFIG_GDRV, handle->config.gdrvDisable);
    if (status == TMC6460_OK)
    {
        handle->feedback.driverEnabled = false;
        handle->targetVelocity = 0;
        handle->targetTorque = 0;
        handle->mode = TMC6460_MODE_DISABLED;
    }
    return status;
}

TMC6460_Status_t TMC6460_EStop(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    (void)TMC6460_WriteReg(TMC6460_REG_FOC_VELOCITY_TARGET, 0u);
    (void)TMC6460_WriteReg(TMC6460_REG_FOC_TORQUE_TARGET, 0u);
    return TMC6460_DisableDriver(handle);
}

TMC6460_Status_t TMC6460_SetVelocityMode(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_MCC_CONFIG_MOTOR_MOTION, handle->config.motorMotionVelocity);
    if (status == TMC6460_OK)
    {
        handle->mode = TMC6460_MODE_VELOCITY;
    }
    return status;
}

TMC6460_Status_t TMC6460_SetVelocity(TMC6460_Handle_t *handle, int32_t velocityRaw)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_SetVelocityMode(handle);
    if (status != TMC6460_OK)
    {
        return status;
    }

    status = TMC6460_WriteReg(TMC6460_REG_FOC_VELOCITY_TARGET, (uint32_t)velocityRaw);
    if (status == TMC6460_OK)
    {
        handle->targetVelocity = velocityRaw;
    }
    return status;
}

TMC6460_Status_t TMC6460_SetTorqueTarget(TMC6460_Handle_t *handle, int32_t torqueRaw)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_FOC_TORQUE_TARGET, (uint32_t)torqueRaw);
    if (status == TMC6460_OK)
    {
        handle->targetTorque = torqueRaw;
    }
    return status;
}

TMC6460_Status_t TMC6460_SetTorqueLimit(TMC6460_Handle_t *handle, uint16_t torqueLimitRaw, uint16_t fluxLimitRaw)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    uint32_t value = ((uint32_t)torqueLimitRaw << 16) | (uint32_t)fluxLimitRaw;
    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_FOC_TORQUE_FLUX_LIMITS, value);
    if (status == TMC6460_OK)
    {
        handle->config.torqueFluxLimits = value;
    }
    return status;
}

TMC6460_Status_t TMC6460_SetVelocityLimit(TMC6460_Handle_t *handle, uint32_t velocityLimitRaw)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_FOC_VELOCITY_LIMITS, velocityLimitRaw);
    if (status == TMC6460_OK)
    {
        handle->config.velocityLimits = velocityLimitRaw;
    }
    return status;
}

TMC6460_Status_t TMC6460_SetPositionTarget(TMC6460_Handle_t *handle, int32_t positionRaw)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_WriteReg(TMC6460_REG_FOC_POSITION_TARGET, (uint32_t)positionRaw);
    if (status == TMC6460_OK)
    {
        handle->mode = TMC6460_MODE_POSITION;
        handle->targetPosition = positionRaw;
    }
    return status;
}

TMC6460_Status_t TMC6460_ReadStatusFlags(TMC6460_Handle_t *handle, uint32_t *statusFlags)
{
    if ((handle == NULL) || (statusFlags == NULL))
    {
        return TMC6460_BAD_PARAMETER;
    }

    TMC6460_Status_t status = TMC6460_ReadReg(TMC6460_REG_CHIP_STATUS_FLAGS, statusFlags);
    if (status == TMC6460_OK)
    {
        handle->feedback.statusFlags = *statusFlags;
        handle->feedback.driverEnabled = ((*statusFlags & TMC6460_STATUS_GDRV_ON_STATE_MASK) != 0u);
        handle->feedback.systemReady = ((*statusFlags & TMC6460_STATUS_SYS_READY_STATE_MASK) != 0u);
        handle->feedback.faultPresent = ((*statusFlags & (TMC6460_STATUS_OVERTEMP_WARN_MASK |
                                                         TMC6460_STATUS_OV_VM_LIMIT_FAIL_MASK |
                                                         TMC6460_STATUS_VM_TEMP_CLIPPED_MASK |
                                                         TMC6460_STATUS_AIN_CLIPPED_MASK |
                                                         TMC6460_STATUS_I_CLIPPED_MASK)) != 0u);
    }
    return status;
}

TMC6460_Status_t TMC6460_ReadFeedback(TMC6460_Handle_t *handle, TMC6460_Feedback_t *feedback)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    uint32_t value = 0u;
    TMC6460_Status_t status = TMC6460_ReadStatusFlags(handle, &value);
    if (status != TMC6460_OK) return status;

    status = TMC6460_ReadReg(TMC6460_REG_FOC_VELOCITY_ACTUAL, &value);
    if (status != TMC6460_OK) return status;
    handle->feedback.velocityActual = (int32_t)value;

    status = TMC6460_ReadReg(TMC6460_REG_FOC_POSITION_ACTUAL, &value);
    if (status != TMC6460_OK) return status;
    handle->feedback.positionActual = (int32_t)value;

    status = TMC6460_ReadReg(TMC6460_REG_FOC_TORQUE_ACTUAL, &value);
    if (status != TMC6460_OK) return status;
    handle->feedback.torqueActual = (int32_t)value;

    status = TMC6460_ReadReg(TMC6460_REG_FOC_FLUX_ACTUAL, &value);
    if (status != TMC6460_OK) return status;
    handle->feedback.fluxActual = (int32_t)value;

    if (feedback != NULL)
    {
        *feedback = handle->feedback;
    }

    return TMC6460_OK;
}

TMC6460_Status_t TMC6460_Task(TMC6460_Handle_t *handle)
{
    if (!isInitialized(handle))
    {
        return TMC6460_NOT_INITIALIZED;
    }

    TMC6460_Status_t status = TMC6460_ReadFeedback(handle, NULL);
    if (status != TMC6460_OK)
    {
        return status;
    }

    if (!handle->stallConfig.enabled)
    {
        handle->previousPosition = handle->feedback.positionActual;
        return TMC6460_OK;
    }

    int32_t positionDelta = handle->feedback.positionActual - handle->previousPosition;
    bool velocityLow = (abs32(handle->feedback.velocityActual) <= handle->stallConfig.minAbsVelocityRaw);
    bool positionNotChanging = (abs32(positionDelta) <= handle->stallConfig.maxAbsPositionDeltaRaw);
    bool torqueHigh = (abs32(handle->feedback.torqueActual) >= handle->stallConfig.minAbsTorqueRaw);
    bool commandedMotion = (abs32(handle->targetVelocity) > handle->stallConfig.minAbsVelocityRaw) ||
                           (handle->mode == TMC6460_MODE_POSITION);

    if (commandedMotion && velocityLow && positionNotChanging && torqueHigh)
    {
        if (handle->stallStartTimeMs == 0u)
        {
            handle->stallStartTimeMs = TMC6460_Port_GetTickMs();
        }
        else if ((TMC6460_Port_GetTickMs() - handle->stallStartTimeMs) >= handle->stallConfig.detectionTimeMs)
        {
            handle->feedback.stallDetected = true;
        }
    }
    else
    {
        handle->stallStartTimeMs = 0u;
        handle->feedback.stallDetected = false;
    }

    handle->previousPosition = handle->feedback.positionActual;
    return TMC6460_OK;
}
