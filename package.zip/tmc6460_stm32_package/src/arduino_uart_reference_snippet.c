/*
 * Arduino Due UART reference snippet from the working TMC6460 test.
 * This is NOT meant to be compiled in STM32 project.
 * It is included only to show the exact logic migrated to STM32 HAL.
 *
 * Wiring used on Arduino Due:
 *   Serial1 TX1 pin 18 -> TMC6460 UART_RX
 *   Serial1 RX1 pin 19 <- TMC6460 UART_TX
 *   GND common
 *   Baud 115200
 */

#if 0
#define TMC_BAUD             115200
#define UART_TIMEOUT_MS      150
#define UART_SYNC_READ       0x42
#define UART_SYNC_WRITE      0x4A

int32_t tmc6460_readRegister(uint16_t icID, uint16_t address, uint32_t *readValue)
{
    (void)icID;
    uint8_t request[2];
    uint8_t response[6];
    uint32_t startMs;
    uint8_t count = 0;

    while (Serial1.available() > 0) { (void)Serial1.read(); }

    request[0] = UART_SYNC_READ | (((address >> 8) & 0x03) << 4);
    request[1] = address & 0xFF;

    Serial1.write(request, 2);
    Serial1.flush();

    startMs = millis();
    while ((count < 6) && ((millis() - startMs) < UART_TIMEOUT_MS))
    {
        if (Serial1.available() > 0)
        {
            response[count++] = (uint8_t)Serial1.read();
        }
    }

    if (count != 6) { return -2; }
    if ((response[0] != request[0]) || (response[1] != request[1])) { return -1; }

    *readValue = ((uint32_t)response[2] << 24) |
                 ((uint32_t)response[3] << 16) |
                 ((uint32_t)response[4] <<  8) |
                 ((uint32_t)response[5] <<  0);

    delayMicroseconds(1000);
    return 0;
}

int32_t tmc6460_writeRegister(uint16_t icID, uint16_t address, uint32_t value)
{
    (void)icID;
    uint8_t request[6];

    while (Serial1.available() > 0) { (void)Serial1.read(); }

    request[0] = UART_SYNC_WRITE | (((address >> 8) & 0x03) << 4);
    request[1] = address & 0xFF;
    request[2] = (value >> 24) & 0xFF;
    request[3] = (value >> 16) & 0xFF;
    request[4] = (value >>  8) & 0xFF;
    request[5] = (value >>  0) & 0xFF;

    Serial1.write(request, 6);
    Serial1.flush();

    delayMicroseconds(1000);
    return 0;
}
#endif
